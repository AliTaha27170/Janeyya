<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class BillController extends Controller
{
    public function add()
    {
        # code...
    }
 
    public function store(Request $request)
    {
        # code...
    }
 
    public function edit($id)
    {
        # code...
    }
 
    public function update(Request $request,$id)
    {
        # code...
    }
 
    public function delete($id)
    {
        # code...
    }
 
    public function show()
    {
        # code...
    }

    public function show_today()
    {
        # code...
    }
}
