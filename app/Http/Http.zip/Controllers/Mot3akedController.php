<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Mot3akedController extends Controller
{
    //
}
