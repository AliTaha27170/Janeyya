<footer class="footer">
    <div class="w-100 clearfix">
        <span class="text-center text-sm-left d-md-inline-block">
        	{{ __('Copyright © '.date("Y").' Radmin v2.6.0. Crafted with')}} 
        	<i class="fa fa-heart text-danger"></i> 
        	<a href="http://lavalite.org/" class="text-dark" target="_blank">
        		{{ __('Lavalite')}}
        	</a>
        </span>
        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center">
        	{{ __('Developed by')}} 
        	<a href="https://rakibul.dev" class="text-dark" target="_blank">
        		{{ __('Md. Rakibul Islam')}}
        	</a>
        </span>
    </div>
</footer>